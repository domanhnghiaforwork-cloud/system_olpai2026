============================================================
HƯỚNG DẪN KHÔI PHỤC DỮ LIỆU TỪ BẢN SAO LƯU (cv01.zip)
Thời gian sao lưu: 04/10/2026 17:06:11
Nguồn dữ liệu: Docker Volume (olp_ai_kma_backend:/app/data/olpai2026.db)
============================================================

1. NẾU CHẠY CỤC BỘ (Không dùng Docker):
   - Giải nén file zip này.
   - Copy file 'olpai2026.db' vào thư mục gốc dự án (system_olpai2026/olpai2026.db).
   - Copy thư mục 'uploads' vào thư mục gốc dự án (system_olpai2026/uploads).
   - Khởi động lại uvicorn backend.

2. NẾU CHẠY BẰNG DOCKER:
   - Giải nén file zip này vào 1 thư mục tạm, ví dụ: 'restore_temp'
   - Chạy lệnh copy database vào container:
     docker cp restore_temp/olpai2026.db olp_ai_kma_backend:/app/data/olpai2026.db
   - Chạy lệnh copy uploads vào container:
     docker cp restore_temp/uploads/. olp_ai_kma_backend:/app/uploads/
   - Khởi động lại container backend nếu cần:
     docker restart olp_ai_kma_backend
============================================================
